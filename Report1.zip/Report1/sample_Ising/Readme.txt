These are sample codes for the report problems.
These run on python3 with numba, matplotlib, numpy, and numba libralies.
Ising-auto.py and . ipynb are almost same with the previsou Ising-Ex1.
Simiraly, Ising-obs.py and Ising-obs.ipynb are same with the Ising-Ex1.
If you want to use them without numba.jit, please use codes in Ising-Exercise.zip provided at lecture No.3.
 
