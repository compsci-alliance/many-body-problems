These are sample codes for the report problems 1-1 and 1-2.
They run on python3 with numba, matplotlib, numpy modules.
Ising-auto.py and . ipynb are almost same with the previsou Ising-Ex1.
Simiraly, Ising-obs.py and Ising-obs.ipynb are same with the Ising-Ex2.
Ising-trg.ipynb and Ising-comp.ipynb are basically taken from Ex1-2 and Ex1-3 in
https://github.com/TsuyoshiOkubo/Introduction-to-Tensor-Network
 
