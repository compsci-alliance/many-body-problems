These are sample codes for the report problems 1-1 and 1-2.
They run on python3 with numba, matplotlib, numpy modules.
Ising-auto.py and . ipynb are almost same with the previsou Ising-Ex1.
Simiraly, Ising-obs.py and Ising-obs.ipynb are same with the Ising-Ex2.
If you want to use them without numba.jit, please use codes in Ising-Exercise.zip provided at lecture No.4.
 
