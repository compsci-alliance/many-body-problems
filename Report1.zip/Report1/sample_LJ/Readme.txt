This is a sample code for the report problem 1-1.
It runs on python3 with numba, matplotlib, numpy modules.
LJ-auto.ipynb is based on the previous MD_LJ_NVE-NVT.ipynb, although I modified the default parameters and the initial conditions, together with the simulation schedule. In this code, we ferst perform NVT simulation, and the we perform observation runs.
 
