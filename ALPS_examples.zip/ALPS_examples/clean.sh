#!/bin/sh

rm -f ALPS.xsl parm9a.* parm9b.* parm9c.* parm9d.*
