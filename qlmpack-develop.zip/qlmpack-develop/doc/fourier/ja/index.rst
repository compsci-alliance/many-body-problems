.. test documentation master file, created by
   sphinx-quickstart on Sat Jan  7 22:10:04 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to HPhi/mVMC Fourie-Transformation utility's documentation!
===================================================================

.. toctree::
   :maxdepth: 3

   fourier_overview_ja.rst
   fourier_tutorial_ja.rst
   fourier_format_ja.rst
   fourier_util_ja.rst
   fourier_contact_ja.rst

.. Indices and tables
.. ==================

.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`

