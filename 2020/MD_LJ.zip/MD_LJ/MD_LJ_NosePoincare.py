#!/usr/bin/env python
# coding: utf-8

# # Sample Molecular Dynamics (MD) simulation code for LJ particle
# ## NVT ensemble by Nose-Poincare method

# 2018, 2019, May, Tsuyoshi Okubo


# In this code you can simulate dynamics of LJ particles with temperature control by using Nose-Poincare method. In this method,
# In this algorithm, an extended Hamiltoninan including thermostad degrees of freedoms $H_{NP}$ is expected to be conserved. Here $H_{NP}$ is given by
# 
# $$ H_{NP} = s\left\{ \sum_{i} \frac{p_i^{\prime2}}{2m_is^2} +\sum_{i} U(q_i)+ \frac{P_s^2}{2Q} + gk_BT_0\log s  - H_0\right\} \\
# = H_N - H_0$$
# 
# where 
# * $T_0$: desired temperature
# * $s$: scale factor for time
# * $q_i$ and $p_i^\prime = sp_i$ :coodinate and scaled momentum
# * $m_i$ : mass 
# * $P_s$ and  $Q$: momentum of the heat bath and its mass, respectively
# * $H_0$ initial value of $H_{N}$
# 
# In this code you can simulate dynamics of LJ particles by the Nose-Poincare-Andersen method. 
# You can change four physical conditions:
# * **N** : the number of particles
# * **rho** : the initical density
# * **T_set** : desired temperature
# 
# For simulation parameter you can set
# * **dt** : time step for integral
# * **step**: integral time steps. Total simulation time is dt * step.
# * **obs_step**: physical quantities observed with this interval.
# * **initial_warming_up**: simulation step without calculating observable for initialization
# 
# For temperature control
# * **Nose_Q**: Mass for thermostad.
# 
# Ref. 奥村久士, 「分子動力学シミュレーションにおける温度・圧力制御」、分子シミュレーション研究会会誌 “アンサンブル” (2008, 2009).

# In[1]:


import numpy as np
from matplotlib import pyplot
from numba import jit ## for speed up, we use jit compile
import argparse

def parse_args():
    parser = argparse.ArgumentParser(description='MD simulation for LJ particles with/wihtout temperature control')
    parser.add_argument('-N',metavar='N',dest='N', type=int, default=1000,
                        help='the number of particles. (default: N = 1000)')
    parser.add_argument('-r', '--rho',metavar='rho',dest='rho', type=float,default=0.8,
                        help='the initial density. (default: 0.8)')
    parser.add_argument('-T', '--Temperature',metavar='T',dest='T', type=float,default=1.0,
                        help='Temperature. (default: T= 1.0)')
    parser.add_argument('--dt', metavar='dt',dest='dt', type=int,default=0.005,
                        help='descrete time step for integral. (default: dt= 0.005)')
    parser.add_argument('-s', '--step',metavar='step',dest='step', type=int,default=2000,
                        help='Total time steps. (default: step=2000)')
    parser.add_argument('--obs_step',metavar='obs_step',dest='obs_step', type=int,default=20,
                        help='physical quantities observed with this interval.(default: obs_step=20)')
    parser.add_argument('--warm_step',metavar='warm_step',dest='warm_step', type=int,default=0,
                        help='simulation step without calculating observable for initialization.(default: warm_step=0)')
    parser.add_argument('--Nose_Q',metavar='Nose_Q',dest='Nose_Q', type=float,default=1.0,
                        help='Mass of thermostad (default: Q = 1.0)')

    return parser.parse_args()




## parameters for system
args = parse_args()
N = args.N # number of particles
rho = args.rho #number density
T_set = args.T # temperature if Nose-Hoober or velocity_scaling is used

## parameters for integration
dt = args.dt
step = args.step
obs_step = args.obs_step
initial_warming_up = args.warm_step ## warming up if one want to avoid initial singular behavior

## parameters for Nose-Poincare algorithm
Nose_Q = args.Nose_Q

## initialization of parameter
L = (N/rho)**(1.0/3.0)

## variables for Temeperature
s = 1.0
Ps = 0.0
Nose_g = 3.0 * N


@jit(nopython = True)
def periodic_boundary(x):
    if np.abs(x) > 0.5:
        x -= np.sign(x)
    return x

@jit(nopython = True)
def periodic_boundary_all(x):
    for i in range(N):
        x[i] = periodic_boundary(x[i])
    return x
@jit(nopython = True)
def force_lj(rx,ry,rz,L,r2_cut=2.5**2):
    ## calculate force, energy and virial for the LJ potential
    L_square = L**2
    r2_inv = 1.0/r2_cut
    r6_inv = r2_inv**3
    pot_base = 4.0 * r6_inv * (r6_inv - 1.0)
    r2_cut_tilde = r2_cut/L_square
    
    fx = np.zeros(N)
    fy = np.zeros(N)
    fz = np.zeros(N)
    Ep = 0.0
    virial = 0.0
    for i in range(N):
        for j in range(i+1,N):
            xij = periodic_boundary(rx[i]-rx[j])
            yij = periodic_boundary(ry[i]-ry[j])
            zij = periodic_boundary(rz[i]-rz[j])
            r2 = xij**2 + yij**2 + zij**2
            if r2 < r2_cut_tilde:
                r2 *= L_square
                r2_inv = 1.0/r2
                r6_inv = r2_inv**3
                
                f_factor = 48.0 * r6_inv * (r6_inv - 0.5)/r2
                fxi = f_factor * xij
                fyi = f_factor * yij
                fzi = f_factor * zij

                fx[i] += fxi
                fy[i] += fyi
                fz[i] += fzi

                fx[j] -= fxi
                fy[j] -= fyi
                fz[j] -= fzi

                Ep += 4.0 * r6_inv * (r6_inv - 1.0) - pot_base
                virial += fxi * xij + fyi * yij + fzi * zij
                
    
    fx *= L
    fy *= L
    fz *= L
    virial *= L_square
    Ep /= N
    return fx,fy,fz,Ep,virial


## initialization of variables
## simple cubic
rx = np.zeros(N)
ry = np.zeros(N)
rz = np.zeros(N)

px = np.zeros(N)
py = np.zeros(N)
pz = np.zeros(N)


l = N**(1.0/3.0)
d = (1.0-1.0/L)/l
nl = int(round(l))

ix = np.zeros(N,dtype=int)
iy = np.zeros(N,dtype=int)
iz = np.zeros(N,dtype=int)
for i in range(N):
    iz[i] = i/nl**2
    iy[i] = (i-iz[i] * nl**2)/nl
    ix[i] = i%nl
rx = -0.5 + d * ix + 0.5/L
ry = -0.5 + d * iy + 0.5/L
rz = -0.5 + d * iz + 0.5/L

rx = periodic_boundary_all(rx)
ry = periodic_boundary_all(ry)
rz = periodic_boundary_all(rz)
fx,fy,fz,Ep,virial = force_lj(rx,ry,rz,L)


Ek = 0.5 * np.sum(px**2 + py**2 + pz**2)/N/(L*s)**2


@jit
def Velocity_Verlet(rx,ry,rz,px,py,pz,fx,fy,fz,dt,L):
    dt2 = dt * 0.5 * L
    dt_L = dt/L**2
    ## v: t + dt/2, r: t+dt
    px += fx * dt2
    py += fy * dt2
    pz += fz * dt2

    rx += px * dt_L
    ry += py * dt_L
    rz += pz * dt_L

    rx = periodic_boundary_all(rx)
    ry = periodic_boundary_all(ry)
    rz = periodic_boundary_all(rz)
    fx,fy,fz,Ep,virial = force_lj(rx,ry,rz,L)

    ## v: t + dt/2 + dt/2
    px += fx * dt2
    py += fy * dt2
    pz += fz * dt2

    Ek = (0.5 * np.sum(px**2 + py**2 + pz**2)/N)/L**2
    
    return rx,ry,rz,px,py,pz,fx,fy,fz,Ep,Ek,virial


@jit(nopython = True)
def Nose_Poincare(rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,L,Ep,dt,H0,T_set,Nose_Q,Nose_g):
    dt2 = dt * 0.5

    ####
    factor = (1.0 + Ps/(2.0*Nose_Q) * dt2)
    s *=  factor**2
    Ps /= factor
    ####

    ####
    dt2s = dt2 * s * L
    px += fx * dt2s
    py += fy * dt2s
    pz += fz * dt2s
    
    Ps -= (Ep * N) * dt2
    ####
        
    ####
    dts = dt /(s * L**2)
    
    rx += px * dts
    ry += py * dts
    rz += pz * dts

    Ek = 0.5 * np.sum(px**2 + py**2 + pz**2)/(L*s)**2
    
    Ps += (Ek - Nose_g * T_set * (np.log(s) + 1.0) + H0) * dt
    #####

    ####
    rx = periodic_boundary_all(rx)
    ry = periodic_boundary_all(ry)
    rz = periodic_boundary_all(rz)
    fx,fy,fz,Ep,virial = force_lj(rx,ry,rz,L)

    dt2s = dt2 * s* L
    px += fx * dt2s
    py += fy * dt2s
    pz += fz * dt2s

    Ps -= (Ep * N) * dt2 
    ####
    
    ####
    factor = (1.0 + Ps/(2.0 * Nose_Q) * dt2)
    s *=  factor**2
    Ps /= factor
    ####
    
    Ek = (0.5 * np.sum(px**2 + py**2 + pz**2)/N)/(L*s)**2

    return rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,Ep,Ek,virial


## main simulation part
## H0 is a conserved quantity (Energy) for Nose-Andersen algorithm
H0 = (Ek + Ep)*N + Ps**2/(2.0 * Nose_Q) + Nose_g * T_set * np.log(s)
for i in range(initial_warming_up):
    rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,Ep,Ek,virial = Nose_Poincare(rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,L,Ep,dt,H0,T_set,Nose_Q,Nose_g)


Pressure = (2.0 * N * Ek + virial)/(3.0*L**3)

## H0 is a conserved quantity (Energy) for Nose-Andersen algorithm
H0 = (Ek + Ep)*N + Ps**2/(2.0 * Nose_Q) + Nose_g * T_set * np.log(s)
H_N = H0 
H_NP =s * (H_N - H0)

Ep_dyn = [Ep]
Ek_dyn = [Ek]
Pressure_dyn = [Pressure]

s_dyn = [s]
Ps_dyn = [Ps]

H_N_dyn = [H_N]
H_NP_dyn = [H_NP]


for i in range(step):
    rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,Ep,Ek,virial = Nose_Poincare(rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,L,Ep,dt,H0,T_set,Nose_Q,Nose_g)
    
    if i % obs_step == 0:
        Pressure = (2.0 * N * Ek + virial)/(3.0*L**3)
        H_N = ((Ek + Ep)*N + Ps**2/(2.0 * Nose_Q) + Nose_g * T_set * np.log(s)) 
        H_NP = s* (H_N - H0)
    
        Ep_dyn.append(Ep)
        Ek_dyn.append(Ek)
        Pressure_dyn.append(Pressure)
        s_dyn.append(s)
        Ps_dyn.append(Ps)
        H_N_dyn.append(H_N)
        H_NP_dyn.append(H_NP)


print("Simulation has been done. Start analysis.")
# In the followings, you can see dynamics of physicsal quantities.
# 
# Note that after initial "turbulence", energy, temperature and pressure become almost constant. In adittion you can see the temperature is correctly controlled to the T_set.
# 
# In the case of the present Nose-Poincare thermostad, $H_NP$ is the conserved qunatities. Thus, you can check how stable the present algorithm is alog longer time evolution.
# 
# 
# 

## plot time series
Ep = np.array(Ep_dyn)
Ek = np.array(Ek_dyn)
Pressure = np.array(Pressure_dyn)
s = np.array(s_dyn)
Ps = np.array(Ps_dyn)
H_N = np.array(H_N_dyn) - H0
H_NP = np.array(H_NP_dyn)


pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Energy")
pyplot.plot(np.arange(Ek.size)*dt*obs_step,Ek+Ep,label="Total Energy")
pyplot.legend()

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Energy")
pyplot.plot(np.arange(Ep.size)*dt*obs_step,Ep,label="Potential Energy")
pyplot.plot(np.arange(Ek.size)*dt*obs_step,Ek,label="Kinetic Energy")
pyplot.plot(np.arange(Ek.size)*dt*obs_step,Ek+Ep,label="Total Energy")
pyplot.legend()

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Temperature")
pyplot.plot([0, Ep.size*dt*obs_step], [T_set, T_set],label="T_set")
pyplot.plot(np.arange(Ek.size)*dt*obs_step,2.0*Ek/3.0,label="Effectiv Temperrature")
pyplot.legend()


pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Pressure")
pyplot.plot(np.arange(Pressure.size)*dt*obs_step,Pressure,label="Effectiv Pressure")
pyplot.legend()

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("H_N-H0")
pyplot.plot(np.arange(H_N.size)*dt*obs_step,H_N,label="H_N-H0")
pyplot.legend()

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("H_NP")
pyplot.plot(np.arange(H_NP.size)*dt*obs_step,H_NP,label="H_NP")
pyplot.legend()





pyplot.show()



## plot thermostad and piston variables
s = np.array(s_dyn)
Ps = np.array(Ps_dyn)

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("s")
pyplot.plot(np.arange(s.size)*dt*obs_step,s,label="s")
pyplot.legend()

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Ps")
pyplot.plot(np.arange(Ps.size)*dt*obs_step,Ps,label="Ps")
pyplot.legend()

pyplot.show()


