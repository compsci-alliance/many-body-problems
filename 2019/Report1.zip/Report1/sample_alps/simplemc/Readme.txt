These files are based on the ALPS tutorial "mc-09-snapshot".
Several input files have been modified for the lecture by Tsuyoshi Okubo.
 
