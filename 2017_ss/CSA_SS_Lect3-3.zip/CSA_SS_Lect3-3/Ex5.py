# Sample code for exercise 5
# 2017 Augst Tsuyoshi Okubo

import numpy as np
import TEBD
import iTEBD
from matplotlib import pyplot

m = 3         ## m = 2S + 1, e.g. m=3 for S=1 
Delta = 1.0   ## Delta for XXZ
hx = 0.0      ## external field along x direction
D = 0.0       ## single ion anisotropy

chi_max = 20  ## maxmum bond dimension at truncation

## parameter for iTEBD
#### 
## tau decreases from tau_max to tau_min gradually
####
tau_max = 0.1     ## start imaginary time tau
tau_min = 0.001   ## final imaginary time tau
T_step= 2000       ## ITE steps

Tn, lam = iTEBD.iTEBD_Simulation(m,Delta,hx,D,chi_max,tau_max,tau_min,T_step)

## Calculate Energy
Env_left,Env_right = iTEBD.Calc_Environment_infinite(Tn,lam,canonical=False)

print "iTEBD simulation with chi_max =",chi_max
print "Energy",iTEBD.Calc_Energy_infinite(Env_left,Env_right,Tn,lam,Delta,hx,D)

## output lambda
for i in range(lam[0].shape[0]):
    print "i, lambda1, lambda2",i,lam[0][i],lam[1][i]

## plot lambda
pyplot.title("infinite S=1 Heisenberg chain")
pyplot.plot(np.arange(lam[0].shape[0]),-np.log(lam[0]),"o")
pyplot.xlabel("Index")
pyplot.ylabel("lambda")
pyplot.show()



