# Sample code for exercise 6
# 2017 Augst Tsuyoshi Okubo

import numpy as np
import scipy.linalg as linalg
import TEBD
import iTEBD
from matplotlib import pyplot

m = 3         ## m = 2S + 1, e.g. m=3 for S=1 
Delta = 1.0   ## Delta for XXZ
hx = 0.0      ## external field along x direction
D = 0.0       ## single ion anisotropy

chi_max = 20  ## maxmum bond dimension at truncation

## parameter for TEBD
#### 
## tau decreases from tau_max to tau_min gradually
####
tau_max = 0.1     ## start imaginary time tau
tau_min = 0.001   ## final imaginary time tau
T_step= 2000       ## ITE steps

Tn, lam = iTEBD.iTEBD_Simulation(m,Delta,hx,D,chi_max,tau_max,tau_min,T_step)

## Calculate Energy
Env_left,Env_right = iTEBD.Calc_Environment_infinite(Tn,lam,canonical=False)

print "iTEBD simulation with chi_max =",chi_max
print "Energy of iTEBD",iTEBD.Calc_Energy_infinite(Env_left,Env_right,Tn,lam,Delta,hx,D)

## Calculate non-trivial phases
chi = lam[0].shape[0]

## define operators
Sp = np.zeros((m,m))
for i in range(1,m):
    Sp[i-1,i] = np.sqrt(i * (m - i))
Sm = np.zeros((m,m))
for i in range(0,m-1):
    Sm[i+1,i] = np.sqrt((i + 1.0) * (m - 1.0 - i))
Sz = np.zeros((m,m))
for i in range(m):
    Sz[i,i] = 0.5 * (m - 1.0) - i

## time reversal
Ry = linalg.expm(0.5*np.pi * (Sp -Sm))
eig, UTR = iTEBD.Transfer_Matrix_SPT_TR(Tn,lam,Ry)

UTR= UTR.reshape(chi,chi).T

UTR /= np.sqrt(np.trace(np.dot(UTR,UTR.T.conj()))/chi)
print "##Time reversal",eig, np.trace(np.dot(UTR,UTR.conj()))/chi

## Inversion
eig_I, UI = iTEBD.Transfer_Matrix_Inv_bond(Tn,lam)
UI = UI.reshape(chi,chi).T
UI /= np.sqrt(np.trace(np.dot(UI,UI.T.conj()))/chi) 

print "##Inversion",eig_I, np.trace(np.dot(UI,UI.conj()))/chi

## set of rotation (D2)

Rx = linalg.expm(0.5j * np.pi * (Sp+Sm))
Rz = linalg.expm(1.0j * np.pi * Sz)
eigx, Ux = iTEBD.Transfer_Matrix_SPT(Tn,lam,Rx)
eigz, Uz = iTEBD.Transfer_Matrix_SPT(Tn,lam,Rz)

Ux = Ux.reshape(chi,chi).T
Ux /= np.sqrt(np.trace(np.dot(Ux,Ux.T.conj()))/chi)

Uz = Uz.reshape(chi,chi).T
Uz /= np.sqrt(np.trace(np.dot(Uz,Uz.T.conj()))/chi)

print "##D2",eigx,eigz, np.trace(np.dot(np.dot(np.dot(Ux,Uz),Ux.T.conj()),Uz.T.conj()))/chi




