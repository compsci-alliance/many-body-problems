# Sample code for exercise 3-4
# 2017 Augst Tsuyoshi Okubo

import numpy as np
import TEBD
import iTEBD
import math
from matplotlib import pyplot

m = 3         ## m = 2S + 1, e.g. m=3 for S=1 
Delta = 1.0   ## Delta for XXZ
hx = 0.0      ## external field along x direction

D_min = 0.0       ## single ion anisotropy
D_max = 2.0
d_D = 0.2
D_step = int((D_max-D_min)/d_D)+1

chi_max = 20  ## maxmum bond dimension at truncation

## parameter for TEBD
#### 
## tau decreases from tau_max to tau_min gradually
####
tau_max = 0.1     ## start imaginary time tau
tau_min = 0.01   ## final imaginary time tau
T_step= 2000       ## ITE steps

E_list = []
xi_list = []
D_list = []
for iD in range(D_step):
    D = D_min + iD * d_D
    Tn, lam = iTEBD.iTEBD_Simulation(m,Delta,hx,D,chi_max,tau_max,tau_min,T_step,output=True)

    Env_left,Env_right = iTEBD.Calc_Environment_infinite(Tn,lam,canonical=False)

    ## Calculate Energy
    E = iTEBD.Calc_Energy_infinite(Env_left,Env_right,Tn,lam,Delta,hx,D)
    
    ## Calculate Correlation length
    eigs = iTEBD.Eingenval_of_Transfer_Matrix(Tn,lam,e_num=2)
    xi = 2.0/np.log(np.abs(eigs[-1]/eigs[-2]))

    D_list.append(D)
    E_list.append(E)
    xi_list.append(xi)

## plot correlation function
pyplot.figure()
pyplot.title("Energy of infinite S=1 Heisenberg chain")
pyplot.plot(D_list,E_list,"o")
pyplot.xlabel("D")
pyplot.ylabel("Energy density")

pyplot.figure()
pyplot.title("Correlation length of infinite S=1 Heisenberg chain")
pyplot.plot(D_list,xi_list,"ro")
pyplot.xlabel("D")
pyplot.ylabel("Correlation length")
pyplot.ylim(ymin=0.0)

pyplot.figure()
pyplot.title("Gap of infinite S=1 Heisenberg chain")
pyplot.plot(D_list,1.0/np.array(xi_list),"go")
pyplot.xlabel("D")
pyplot.ylabel("1/(Correlation length)")
pyplot.ylim(ymin=0.0)

pyplot.show()



