# Sample code for exercise 1-1
# 2017 Augst Tsuyoshi Okubo

import numpy as np
import scipy.linalg as linalg
from matplotlib import pyplot

N=10## Chain length 
m = 3         ## m = 2S + 1, e.g. m=3 for S=1 
vec = (np.random.rand(m**N)-0.5) + 1.0j * (np.random.rand(m**N)-0.5)

## Make matrix from wave function
Mat = vec[:].reshape(m**(N/2),m**(N-N/2))

## SVD
U,s,VT = linalg.svd(Mat,full_matrices=False)

## Entanglement entropy
EE = -np.sum(s**2*np.log(s**2))
print "normalization=",np.sum(s**2)
s /=np.sqrt(np.sum(s**2))

EE = -np.sum(s**2*np.log(s**2))
print "EE=",EE

## plot singular values
pyplot.title(repr(N)+" sites random vector")
pyplot.plot(np.arange(m**(N/2)),s,"o")
pyplot.xlabel("index")
pyplot.ylabel("sigular value")
pyplot.yscale("log")
pyplot.show()

    
