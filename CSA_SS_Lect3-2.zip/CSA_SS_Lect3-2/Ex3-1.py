# Sample code for exercise 3-1
# 2017 Augst Tsuyoshi Okubo

import numpy as np
import scipy.linalg as linalg
import ED
import TEBD
from matplotlib import pyplot

N=10           ## Chain length 
m = 3         ## m = 2S + 1, e.g. m=3 for S=1 
Delta = 1.0   ## Delta for XXZ
hx = 0.0      ## external field along x direction
D = 0.0       ## single ion anisotropy

chi_max = 20  ## maxmum bond dimension at truncation

## parameter for TEBD
#### 
## tau decreases from tau_max to tau_min gradually
####
tau_max = 0.1     ## start imaginary time tau
tau_min = 0.001   ## final imaginary time tau
T_step=2000       ## ITE steps
output_dyn_num = 100 ## output steps

eig_val,eig_vec = ED.Calc_GS(m,Delta,hx,D,N,k=1)

Eg = eig_val[0]/(N-1)

Tn, lam,T_list,E_list,mz_list = TEBD.TEBD_Simulation(m,Delta,hx,D,N,chi_max,tau_max,tau_min,T_step,output_dyn=True,output_dyn_num=100)

## Calculate Energy
Env_left,Env_right = TEBD.Calc_Environment(Tn,lam,canonical=False)

print "S=1 N-site open Heisenberg chain"
print "N=",N
print "Ground state energy per bond=", Eg
print "TEBD simulation with chi_max =",chi_max
print "Energy of TEBD",TEBD.Calc_Energy(Env_left,Env_right,Tn,lam,Delta,hx,D)

## plot energy dynamics
pyplot.title(repr(N)+" site S=1 Heisenberg chain")
pyplot.plot(T_list[1:],E_list[1:],"o")
pyplot.xlabel("T")
pyplot.ylabel("E(T)")
pyplot.axhline(y=Eg, color='red')
pyplot.show()
