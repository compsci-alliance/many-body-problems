# Copyright (c) 2018 Yusuke Nomura
# Usage of RBM solver

# Programs 

 ./src/SD/  => RBM solver using using steepest descent (SD)
 ./src/SR/  => RBM solver using using stochastic reconfiguration (SR) method  


# Compilation 

 1. Go to ./src/SD/ or ./src/SR  

     cd ./src/SD/
       or     
     cd ./src/SR/    

 2. Edit Makefile 


 3. Type "make"
   
     If the executable file RBM_solver_SD(R).x exists, the compilation is successful     


# Examples
 
 ./examples/1D_AF_chain/8site   => 1D antiferromagnetic Heisenberg model (8site)  
 ./examples/1D_AF_chain/16site  => 1D antiferromagnetic Heisenberg model (16site)


# Execution

 1. copy executable files to working directory 

 2. ./RBM_solver_SD(R).x > log

    RBM_solver_SD(R).x requires RBM.input and fock_state_list.txt as inputs
    log is standard output    


