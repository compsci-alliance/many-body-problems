
# coding: utf-8

# # Sample Molecular Dynamics (MD) simulation code for LJ particle
# ## NVT ensemble by Nose-Poincare method
# In this algorithm, an extended Hamiltoninan including thermostad degree of freedoms is expected to be conserved. It is denoted as H_NP in the following code.
# 
# 
# 

import numpy as np
from matplotlib import pyplot
from numba import jit ## for speed up, we use jit compile


## parameters for system
N=1000 # number of particles
rho = 0.8 #number density at the initial state
T_set = 1.0 # temperature 

## parameters for integration
dt = 0.005 
initial_warming_up = 0 ## warming up if one want to avoid initial singular behavior
step = 2000
obs_step = 20

## parameters for Nose-Andersen algorithm
Nose_Q = 1.0


## initialization of parameter
L = (N/rho)**(1.0/3.0)

## variables for Temeperature
s = 1.0
Ps = 0.0
Nose_g = 3.0 * N



@jit
def periodic_boundary(x):
    if np.abs(x) > 0.5:
        x -= np.sign(x)
    return x

@jit
def periodic_boundary_all(x):
    for i in xrange(N):
        x[i] = periodic_boundary(x[i])
    return x
@jit
def force_lj(rx,ry,rz,L,r2_cut=2.5**2):
    ## calculate force, energy and virial for the LJ potential
    L_square = L**2
    r2_inv = 1.0/r2_cut
    r6_inv = r2_inv**3
    pot_base = 4.0 * r6_inv * (r6_inv - 1.0)
    r2_cut_tilde = r2_cut/L_square
    
    fx = np.zeros(N)
    fy = np.zeros(N)
    fz = np.zeros(N)
    Ep = 0.0
    virial = 0.0
    for i in xrange(N):
        for j in xrange(i+1,N):
            xij = periodic_boundary(rx[i]-rx[j])
            yij = periodic_boundary(ry[i]-ry[j])
            zij = periodic_boundary(rz[i]-rz[j])
            r2 = xij**2 + yij**2 + zij**2
            if r2 < r2_cut_tilde:
                r2 *= L_square
                r2_inv = 1.0/r2
                r6_inv = r2_inv**3
                
                f_factor = 48.0 * r6_inv * (r6_inv - 0.5)/r2
                fxi = f_factor * xij
                fyi = f_factor * yij
                fzi = f_factor * zij

                fx[i] += fxi
                fy[i] += fyi
                fz[i] += fzi

                fx[j] -= fxi
                fy[j] -= fyi
                fz[j] -= fzi

                Ep += 4.0 * r6_inv * (r6_inv - 1.0) - pot_base
                virial += fxi * xij + fyi * yij + fzi * zij
                
    
    fx *= L
    fy *= L
    fz *= L
    virial *= L_square
    Ep /= N
    return fx,fy,fz,Ep,virial


## initialization of variables
## simple cubic
rx = np.zeros(N)
ry = np.zeros(N)
rz = np.zeros(N)

px = np.zeros(N)
py = np.zeros(N)
pz = np.zeros(N)


l = N**(1.0/3.0)
d = (1.0-1.0/L)/l
nl = int(round(l))

ix = np.zeros(N,dtype=int)
iy = np.zeros(N,dtype=int)
iz = np.zeros(N,dtype=int)
for i in xrange(N):
    iz[i] = i/nl**2
    iy[i] = (i-iz[i] * nl**2)/nl
    ix[i] = i%nl
rx = -0.5 + d * ix + 0.5/L
ry = -0.5 + d * iy + 0.5/L
rz = -0.5 + d * iz + 0.5/L

rx = periodic_boundary_all(rx)
ry = periodic_boundary_all(ry)
rz = periodic_boundary_all(rz)
fx,fy,fz,Ep,virial = force_lj(rx,ry,rz,L)


Ek = 0.5 * np.sum(px**2 + py**2 + pz**2)/N/(L*s)**2


@jit
def Velocity_Verlet(rx,ry,rz,px,py,pz,fx,fy,fz,dt,L):
    dt2 = dt * 0.5 * L
    dt_L = dt/L**2
    ## v: t + dt/2, r: t+dt
    px += fx * dt2
    py += fy * dt2
    pz += fz * dt2

    rx += px * dt_L
    ry += py * dt_L
    rz += pz * dt_L

    rx = periodic_boundary_all(rx)
    ry = periodic_boundary_all(ry)
    rz = periodic_boundary_all(rz)
    fx,fy,fz,Ep,virial = force_lj(rx,ry,rz,L)

    ## v: t + dt/2 + dt/2
    px += fx * dt2
    py += fy * dt2
    pz += fz * dt2

    Ek = (0.5 * np.sum(px**2 + py**2 + pz**2)/N)/L**2
    
    return rx,ry,rz,px,py,pz,fx,fy,fz,Ep,Ek,virial


@jit
def Nose_Poincare(rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,L,Ep,dt,H0,T_set,Nose_Q,Nose_g):
    dt2 = dt * 0.5

    ####
    factor = (1.0 + Ps/(2.0*Nose_Q) * dt2)
    s *=  factor**2
    Ps /= factor
    ####

    ####
    dt2s = dt2 * s * L
    px += fx * dt2s
    py += fy * dt2s
    pz += fz * dt2s
    
    Ps -= (Ep * N) * dt2
    ####
        
    ####
    dts = dt /(s * L**2)
    
    rx += px * dts
    ry += py * dts
    rz += pz * dts

    Ek = 0.5 * np.sum(px**2 + py**2 + pz**2)/(L*s)**2
    
    Ps += (Ek - Nose_g * T_set * (np.log(s) + 1.0) + H0) * dt
    #####

    ####
    rx = periodic_boundary_all(rx)
    ry = periodic_boundary_all(ry)
    rz = periodic_boundary_all(rz)
    fx,fy,fz,Ep,virial = force_lj(rx,ry,rz,L)

    dt2s = dt2 * s* L
    px += fx * dt2s
    py += fy * dt2s
    pz += fz * dt2s

    Ps -= (Ep * N) * dt2 
    ####
    
    ####
    factor = (1.0 + Ps/(2.0 * Nose_Q) * dt2)
    s *=  factor**2
    Ps /= factor
    ####
    
    Ek = (0.5 * np.sum(px**2 + py**2 + pz**2)/N)/(L*s)**2

    return rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,Ep,Ek,virial


## main simulation part
for i in xrange(initial_warming_up):
    rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,Ep,Ek,virial = Nose_Poincare(rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,L,Ep,dt,H0,T_set,Nose_Q,Nose_g)


Pressure = (2.0 * N * Ek + virial)/(3.0*L**3)

## H0 is a conserved quantity (Energy) for Nose-Andersen algorithm
H0 = (Ek + Ep)*N + Ps**2/(2.0 * Nose_Q) + Nose_g * T_set * np.log(s)
H_NP =0.0

Ep_dyn = [Ep]
Ek_dyn = [Ek]
Pressure_dyn = [Pressure]

s_dyn = [s]
Ps_dyn = [Ps]

H_NP_dyn = [H_NP]


for i in xrange(step):
    rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,Ep,Ek,virial = Nose_Poincare(rx,ry,rz,px,py,pz,fx,fy,fz,s,Ps,L,Ep,dt,H0,T_set,Nose_Q,Nose_g)
    
    if i % obs_step == 0:
        Pressure = (2.0 * N * Ek + virial)/(3.0*L**3)
        H_NP = ((Ek + Ep)*N + Ps**2/(2.0 * Nose_Q) + Nose_g * T_set * np.log(s)) - H0
    
        Ep_dyn.append(Ep)
        Ek_dyn.append(Ek)
        Pressure_dyn.append(Pressure)
        s_dyn.append(s)
        Ps_dyn.append(Ps)
        H_NP_dyn.append(H_NP)


## plot time series
Ep = np.array(Ep_dyn)
Ek = np.array(Ek_dyn)
Pressure = np.array(Pressure_dyn)
s = np.array(s_dyn)
Ps = np.array(Ps_dyn)
H_NP = np.array(H_NP_dyn)

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Energy")
pyplot.plot(np.arange(Ek.size)*dt*obs_step,Ek+Ep,label="Total Energy")
pyplot.legend()

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Energy")
pyplot.plot(np.arange(Ep.size)*dt*obs_step,Ep,label="Potential Energy")
pyplot.plot(np.arange(Ek.size)*dt*obs_step,Ek,label="Kinetic Energy")
pyplot.plot(np.arange(Ek.size)*dt*obs_step,Ek+Ep,label="Total Energy")
pyplot.legend()

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Temperature")
pyplot.plot([0, Ep.size*dt*obs_step], [T_set, T_set],label="T_set")
pyplot.plot(np.arange(Ek.size)*dt*obs_step,2.0*Ek/3.0,label="Effectiv Temperrature")
pyplot.legend()


pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Pressure")
pyplot.plot(np.arange(Pressure.size)*dt*obs_step,Pressure,label="Effectiv Pressure")
pyplot.legend()

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Conserved Energy-E(t=0)")
pyplot.plot(np.arange(H_NP.size)*dt*obs_step,H_NP,label="Conserved Energy")
pyplot.legend()



pyplot.show()




## plot thermostad and piston variables
s = np.array(s_dyn)
Ps = np.array(Ps_dyn)

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("s")
pyplot.plot(np.arange(s.size)*dt*obs_step,s,label="s")
pyplot.legend()

pyplot.figure()
pyplot.title("N= " + repr(N)+" LJ particles:"+ " time series")
pyplot.xlabel("t")
pyplot.ylabel("Ps")
pyplot.plot(np.arange(Ps.size)*dt*obs_step,Ps,label="Ps")
pyplot.legend()

pyplot.show()






